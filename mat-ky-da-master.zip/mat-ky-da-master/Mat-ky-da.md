# Mật kỳ đà # Tác dụng của mật kỳ đà
Mật kỳ đà là mật của con kỳ đà. Theo kinh nghiệm nhân dân mật kỳ đà có nhiều tác dụng tốt cho sức khỏe, thường dùng làm thuốc
## [Tác dụng của mật kỳ đà](https://caycohoaqua.com/blog/mat-ky-da-co-tac-dung-gi)
### + Tác dụng chữa hen phế quản
### + Tác dụng chữa viêm phế quản co thắt
### + Tác dụng chữa viêm phế quản tắc nghẽn
### + Tác dụng chữa khó thở, thở khò khè

![alt](http://https://uploads-ssl.webflow.com/5f4c6e0c5cd6d9406c2680b1/5f4c735a7330e52705e9562e_mat-ky-da-loai-nho-1.jpg)

## Các tác dụng khác
+ Tác dụng chữa run tay chân
+ Tác dụng chữa trào ngược dạ dày, cái này ai hợp thì mới dùng được
+ Tác dụng chữa cao huyết áp

## Cách sử dụng mật kỳ đà
Mời các bạn xem tại đây : [Cách sử dụng mật kỳ đà](https://caycohoaqua.webflow.io/posts/cach-su-dung-mat-ky-da)

## Giá mật kỳ đà
Mời các bạn xem tại đây : [Giá mật kỳ đà](https://caycohoaqua.com/blog/mat-ky-da-co-tac-dung-gi)
Xem tại mục thứ 9 - các bạn nhé

## Mỡ kỳ đà có tác dụng gì

## Da kỳ đà có tác dụng gì

## Kỳ đà ngâm rượu có tác dụng gì không

## Tiết kỳ đà pha rượu

## Đuôi kỳ đà có tác dụng gì

## Mật kỳ đà chữa cao huyết áp


===================
Mời bạn xem các 
